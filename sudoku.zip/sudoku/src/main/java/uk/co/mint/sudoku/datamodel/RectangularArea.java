package uk.co.mint.sudoku.datamodel;

public final class RectangularArea extends AbstractArea {          
}
