package uk.co.mint.sudoku.datamodel;

public final class SquareArea extends AbstractArea {          
}
