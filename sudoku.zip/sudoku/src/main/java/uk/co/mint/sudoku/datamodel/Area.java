package uk.co.mint.sudoku.datamodel;

import java.util.List;

public interface Area {
    public List<Integer> getCells();
}
