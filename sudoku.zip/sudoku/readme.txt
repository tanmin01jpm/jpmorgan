
1) use the following to do the unit tests and show its test coverage, currently 100% on the line and branch coverages.
	
	mvn clean cobertura:cobertura
	
	The result can be found at \target\site\cobertura\index.html
	
	
	