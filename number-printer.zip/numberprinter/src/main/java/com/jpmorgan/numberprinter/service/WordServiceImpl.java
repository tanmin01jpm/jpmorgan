package com.jpmorgan.numberprinter.service;

import java.util.Map;

import com.jpmorgan.numberprinter.model.Unit;
import com.jpmorgan.numberprinter.model.WordUnit;

public class WordServiceImpl extends NumberPrintServiceImpl {

	final static String[] UNIT_WORDS = { "One", "Two", "Three", "Four", "Five",
			"Six", "Seven", "Eight", "Nine", "Ten" };
	final static String[] TEEN_WORDS = { "Ten", "Eleven", "Twelve", "Thirteen",
			"Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen",
			"Nineteen" };
	final static String[] TENS_WORDS = { "Ten", "Twenty", "Thirty", "Fourty",
			"Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

	public WordServiceImpl(Unit[] units) {
		this.units = units;
	}

	String buildDiplay(Map<String, Integer> map) {
		final String suffixForHundred = " and ";
		StringBuilder stringBuilder = new StringBuilder();

		for (String key : map.keySet()) {
			if (key.equals(WordUnit.THOUSAND.getName())
					&& map.get(key).intValue() > 0) {
				stringBuilder.append(UNIT_WORDS[map.get(
						WordUnit.THOUSAND.getName()).intValue() - 1]);
				stringBuilder.append(" " + WordUnit.THOUSAND.getName()+ " ");
			} else if (key.equals(WordUnit.HUNDRED.getName())
					&& map.get(key).intValue() > 0) {
				stringBuilder.append(UNIT_WORDS[map.get(
						WordUnit.HUNDRED.getName()).intValue() - 1]);
				stringBuilder.append(" " + WordUnit.HUNDRED.getName()
						+ suffixForHundred);
			} else if (key.equals(WordUnit.TEN.getName())
					&& map.get(key).intValue() > 0) {
				if (map.get(key).intValue() == 1) {
					if (map.get(key).intValue() > 0) {
						stringBuilder.append(TEEN_WORDS[map.get(
								WordUnit.ONE.getName()).intValue()]);
					}
					break;
				} else {
					stringBuilder.append(TENS_WORDS[map.get(
							WordUnit.TEN.getName()).intValue() - 1]);
					stringBuilder.append(" ");
				}
			} else if (key.equals(WordUnit.ONE.getName())
					&& map.get(key).intValue() > 0) {
				stringBuilder.append(UNIT_WORDS[map.get(key).intValue() - 1]);
			}
			
		}

		if (stringBuilder.toString().trim().endsWith(suffixForHundred.trim())) {
			return stringBuilder.toString().replaceAll(suffixForHundred, "").trim();
		}
		return stringBuilder.toString().trim();
	}
}
