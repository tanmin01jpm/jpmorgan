package com.jpmorgan.numberprinter.service;

import java.util.LinkedHashMap;
import java.util.Map;

import com.jpmorgan.numberprinter.model.Unit;

abstract class NumberPrintServiceImpl implements
		NumberPrintService {

	Unit[] units;
	public String display(int input) {
		Map<String, Integer> map = generateMap(input);
		return buildDiplay(map);
	}

	Map<String, Integer> generateMap(int input) {
		// linked hash map to keep the order
		Map<String, Integer> map = new LinkedHashMap<String, Integer>();
		for (Unit unit : units) {
			input = count(map, input, unit);
		}
		return map;
	}

	private int count(Map<String, Integer> map, int input, Unit unit) {
		int count = input / unit.getValue();
		map.put(unit.getName(), count);
		return input % unit.getValue();
	}

	abstract String buildDiplay(Map<String, Integer> map);
}
