package com.jpmorgan.numberprinter.service;

import java.util.Map;

import com.jpmorgan.numberprinter.model.RomanUnit;
import com.jpmorgan.numberprinter.model.Unit;

public class RomanServiceImpl extends NumberPrintServiceImpl {
	static final String LONG_FOUR = "IIII";
	static final String SHORT_FOUR = "IV";
	static final String LONG_NINE = "VIV";
	static final String SHORT_NINE = "IX";
	static final String LONG_FOUTY = "XXXX";
	static final String SHORT_FOUTY = "XL";
	static final String LONG_NINTY = "LXL";
	static final String SHORT_NINTY = "XC";
	static final String LONG_FOURH = "CCCC";
	static final String SHORT_FOURH = "CD";
	static final String LONG_NINEH = "DCD";
	static final String SHORT_NINEH = "CM";
	
	public RomanServiceImpl(Unit[] units) {
		super();
		this.units= units;
	}
	
	String buildDiplay(Map<String, Integer> map) {
		StringBuilder stringBuilder = new StringBuilder();

		for (String key : map.keySet()) {
			for (int i = 0; i < map.get(key).intValue(); i++) {
				stringBuilder.append(key);
			}
			longToShort(stringBuilder, key);
		}
		return stringBuilder.toString();
	}

	private void longToShort(StringBuilder sb, String key) {
		if (key.equals(RomanUnit.C.name())) {
			LongToShortProcessor.process(sb, LONG_FOURH, SHORT_FOURH, LONG_NINEH,
					SHORT_NINEH);
		}
		if (key.equals(RomanUnit.X.name())) {
			LongToShortProcessor.process(sb, LONG_FOUTY, SHORT_FOUTY, LONG_NINTY,
					SHORT_NINTY);
		}
		if (key.equals(RomanUnit.I.name())) {
			LongToShortProcessor.process(sb, LONG_FOUR, SHORT_FOUR, LONG_NINE,
					SHORT_NINE);
		}
	}
}
