package com.jpmorgan.numberprinter.service;

final class LongToShortProcessor {
	
	static void process(StringBuilder sb,String fourL, String fourS, String nineL, String nineS) {
		process(sb, fourL, fourS); 
		process(sb,nineL,nineS); 
	}
	
	static void process(StringBuilder stringBuilder, String longS, String shortS) {
		if (stringBuilder.toString().endsWith(longS)) {
			stringBuilder.replace(stringBuilder.length() - longS.length(),
					stringBuilder.length(), shortS);
		}
	}
}
