package com.jpmorgan.numberprinter.model;

public enum RomanUnit implements Unit{

	M("M",1000),D("D",500),C("C",100),L("L",50),X("X",10),V("V",5),I("I",1);
	
	private final String name;  
    private final int value;    
    RomanUnit(String name, int price) {
        this.name = name;
        this.value = price;
    }
    
    public String getName() { return this.name; }
    public int getValue() { return this.value; } 
}

