package com.jpmorgan.numberprinter.model;

public interface Unit {
	int getValue();
	String getName();
}
