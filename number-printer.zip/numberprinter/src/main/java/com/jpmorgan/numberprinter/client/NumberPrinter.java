package com.jpmorgan.numberprinter.client;

import java.util.LinkedList;
import java.util.List;

import com.jpmorgan.numberprinter.exception.InvalidInputNumberException;
import com.jpmorgan.numberprinter.service.NumberPrintService;

public final class NumberPrinter {

	static int MAX = 3999;
	static int MIN = 1;
	List<NumberPrintService> services;

	NumberPrinter(NumberPrintService... numberPrintServices) {
		this.services = new LinkedList<NumberPrintService>();
		for (NumberPrintService numberPrintService : numberPrintServices) {
			this.services.add(numberPrintService);
		}
	}

	public String print(int input) {
		StringBuilder stringBuilder = new StringBuilder();
		if (input < MIN || input > MAX) {
			throw new InvalidInputNumberException(
					"Input Number is outside the boundary. The range is ["
							+ MIN + "-" + MAX+ "]");
		}

		for (NumberPrintService numberPrintService : services) {
			stringBuilder.append(numberPrintService.display(input));
			stringBuilder.append("/n");
		}
		return stringBuilder.toString();
	}
}
