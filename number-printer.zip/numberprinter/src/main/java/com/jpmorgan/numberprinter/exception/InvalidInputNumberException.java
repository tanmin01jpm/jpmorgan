package com.jpmorgan.numberprinter.exception;

final public class InvalidInputNumberException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8282678714984281434L;
	
	/**
     * Constructor that allows a specific error message to be specified.
     *
     * @param message the detail message.
     */
    public InvalidInputNumberException(String message) {
        super(message);
    }
}
