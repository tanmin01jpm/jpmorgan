package com.jpmorgan.numberprinter.model;

public enum WordUnit implements Unit {
	THOUSAND("Thousand",1000),HUNDRED("Hundred",100),TEN("Ten",10),ONE("One",1);
	private final String name;  
    private final int value;    
    WordUnit(String name, int price) {
        this.name = name;
        this.value = price;
    }
    
    public String getName() { return this.name; }
    public int getValue() { return this.value; } 
 
}

