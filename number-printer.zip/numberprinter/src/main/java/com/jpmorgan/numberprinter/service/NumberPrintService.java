package com.jpmorgan.numberprinter.service;

public interface NumberPrintService{
	String display(int input);
}
