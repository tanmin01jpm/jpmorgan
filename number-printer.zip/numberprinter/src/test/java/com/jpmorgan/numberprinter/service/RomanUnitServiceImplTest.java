package com.jpmorgan.numberprinter.service;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.jpmorgan.numberprinter.model.RomanUnit;

public class RomanUnitServiceImplTest {

	@Test
	public void testRomanUnitLessThan10() {

		NumberPrintService romanUnitService = new RomanServiceImpl(RomanUnit.values());
		assertTrue(romanUnitService.display(1).equals(RomanUnit.I.name()));
		assertTrue(romanUnitService.display(2).equals(
				RomanUnit.I.name() + RomanUnit.I.name()));
		assertTrue(romanUnitService.display(3).equals(
				RomanUnit.I.name() + RomanUnit.I.name() + RomanUnit.I.name()));
		assertTrue(romanUnitService.display(4).equals(
				RomanServiceImpl.SHORT_FOUR));
		assertTrue(romanUnitService.display(5).equals(RomanUnit.V.name()));
		assertTrue(romanUnitService.display(6).equals(RomanUnit.V.name() + "I"));
		assertTrue(romanUnitService.display(7)
				.equals(RomanUnit.V.name() + "II"));
		assertTrue(romanUnitService.display(8).equals(
				RomanUnit.V.name() + "III"));
		assertTrue(romanUnitService.display(9).equals("IX"));
	}

	@Test
	public void testRomanUnitLessThan20() {
		NumberPrintService romanUnitService = new RomanServiceImpl(
				RomanUnit.values());
		assertTrue(romanUnitService.display(10).equals(RomanUnit.X.name()));

		assertTrue(romanUnitService.display(11)
				.equals("X" + RomanUnit.I.name()));
		assertTrue(romanUnitService.display(12).equals("XII"));
		assertTrue(romanUnitService.display(13).equals("XIII"));
		assertTrue(romanUnitService.display(14).equals("XIV"));
		assertTrue(romanUnitService.display(15).equals("XV"));
		assertTrue(romanUnitService.display(14).equals("XIV"));
		assertTrue(romanUnitService.display(19).equals("XIX"));

	}

	@Test
	public void testRomanUnits() {
		NumberPrintService romanUnitService = new RomanServiceImpl(
				RomanUnit.values());

		assertTrue(romanUnitService.display(20).equals("XX"));
		assertTrue(romanUnitService.display(555).equals("DLV"));
		assertTrue(romanUnitService.display(999).equals("CMXCIX"));
		assertTrue(romanUnitService.display(1974).equals("MCMLXXIV"));
		assertTrue(romanUnitService.display(2999).equals("MMCMXCIX"));
		assertTrue(romanUnitService.display(3999).equals("MMMCMXCIX"));
		
	}
}
