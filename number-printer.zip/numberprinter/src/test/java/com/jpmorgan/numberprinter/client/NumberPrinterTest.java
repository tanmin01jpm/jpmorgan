package com.jpmorgan.numberprinter.client;

import static org.mockito.Mockito.when;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.jpmorgan.numberprinter.exception.InvalidInputNumberException;
import com.jpmorgan.numberprinter.service.RomanServiceImpl;
import com.jpmorgan.numberprinter.service.WordServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class NumberPrinterTest {

	@Mock
	RomanServiceImpl romanServiceImpl;

	@Mock
	WordServiceImpl wordServiceImpl;

	@Test(expected=InvalidInputNumberException.class)
	public void testInvalidInputMax() {
		NumberPrinter numberPrinter = new NumberPrinter(romanServiceImpl, wordServiceImpl);
		numberPrinter.print(4000);

	}
	
	@Test(expected=InvalidInputNumberException.class)
	public void testInvalidInputMin() {
		NumberPrinter numberPrinter = new NumberPrinter(romanServiceImpl, wordServiceImpl);
		numberPrinter.print(0);

	}
	
	@Test
	public void test() {
		NumberPrinter numberPrinter = new NumberPrinter(romanServiceImpl, wordServiceImpl);
		int input =10;
		when(romanServiceImpl.display(input)).thenReturn("X");
		when(wordServiceImpl.display(input)).thenReturn("Ten");
		assertTrue(numberPrinter.print(input).equalsIgnoreCase("X/nTen/n"));
	}

}
