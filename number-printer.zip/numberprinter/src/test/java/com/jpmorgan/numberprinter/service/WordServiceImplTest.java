package com.jpmorgan.numberprinter.service;

import org.junit.Test;
import static org.junit.Assert.assertTrue;
import com.jpmorgan.numberprinter.model.WordUnit;

public class WordServiceImplTest {

	@Test
	public void testLessThan10() {
		NumberPrintService wordUnitService = new WordServiceImpl(WordUnit.values());	
		assertTrue(wordUnitService.display(1).equals("One"));
		assertTrue(wordUnitService.display(2).equals("Two"));
		assertTrue(wordUnitService.display(3).equals("Three"));
		assertTrue(wordUnitService.display(4).equals("Four"));
		assertTrue(wordUnitService.display(5).equals("Five"));
		assertTrue(wordUnitService.display(6).equals("Six"));
		assertTrue(wordUnitService.display(7).equals("Seven"));
		assertTrue(wordUnitService.display(8).equals("Eight"));
		assertTrue(wordUnitService.display(9).equals("Nine"));
	}
	
	@Test
	public void testLessThan20() {
		NumberPrintService wordUnitService = new WordServiceImpl(WordUnit.values());
		assertTrue(wordUnitService.display(10).equals("Ten"));
		assertTrue(wordUnitService.display(11).equals("Eleven"));
		assertTrue(wordUnitService.display(12).equals("Twelve"));
		assertTrue(wordUnitService.display(13).equals("Thirteen"));
		assertTrue(wordUnitService.display(14).equals("Fourteen"));
		assertTrue(wordUnitService.display(15).equals("Fifteen"));
		assertTrue(wordUnitService.display(16).equals("Sixteen"));
		assertTrue(wordUnitService.display(17).equals("Seventeen"));
		assertTrue(wordUnitService.display(18).equals("Eighteen"));
		assertTrue(wordUnitService.display(19).equals("Nineteen"));	
	}
	
	@Test
	public void testTens() {
		NumberPrintService wordUnitService = new WordServiceImpl(WordUnit.values());
		assertTrue(wordUnitService.display(20).equals("Twenty"));
		assertTrue(wordUnitService.display(31).equals("Thirty One"));
		assertTrue(wordUnitService.display(42).equals("Fourty Two"));
		assertTrue(wordUnitService.display(50).equals("Fifty"));
		assertTrue(wordUnitService.display(60).equals("Sixty"));
		assertTrue(wordUnitService.display(70).equals("Seventy"));
		assertTrue(wordUnitService.display(80).equals("Eighty"));
		assertTrue(wordUnitService.display(96).equals("Ninety Six"));	
	}
	
	@Test
	public void testOthers() {
		NumberPrintService wordUnitService = new WordServiceImpl(WordUnit.values());
		assertTrue(wordUnitService.display(100).equals("One Hundred"));
		assertTrue(wordUnitService.display(200).equals("Two Hundred"));
		assertTrue(wordUnitService.display(313).equals("Three Hundred and Thirteen"));
		assertTrue(wordUnitService.display(21).equals("Twenty One"));
		assertTrue(wordUnitService.display(105).equals("One Hundred and Five"));
		assertTrue(wordUnitService.display(3999).equals("Three Thousand Nine Hundred and Ninety Nine"));
		assertTrue(wordUnitService.display(1000).equals("One Thousand"));
	}
}
